const SellerPage = () => {
  return <h1>Seller Page (placeholder)</h1>;
};

export default SellerPage;
