const UserPage = () => {
  return <h1>User Page (placeholder)</h1>;
};

export default UserPage;
