const ShipperPage = () => {
  return <h1>Shipper Page (placeholder)</h1>;
};

export default ShipperPage;
