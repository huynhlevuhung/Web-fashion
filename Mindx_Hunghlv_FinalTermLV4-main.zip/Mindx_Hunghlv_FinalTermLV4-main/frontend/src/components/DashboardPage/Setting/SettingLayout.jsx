import React from "react";

const SettingsLayout = () => {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Settings Layout</h1>
      <p>Đây là giao diện Cài đặt hệ thống.</p>
    </div>
  );
};

export default SettingsLayout;
