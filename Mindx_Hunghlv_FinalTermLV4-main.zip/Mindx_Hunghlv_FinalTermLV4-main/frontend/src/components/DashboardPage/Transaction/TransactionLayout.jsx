import React from "react";

const TransactionLayout = () => {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Transaction Layout</h1>
      <p>Đây là giao diện quản lý Giao dịch.</p>
    </div>
  );
};

export default TransactionLayout;
