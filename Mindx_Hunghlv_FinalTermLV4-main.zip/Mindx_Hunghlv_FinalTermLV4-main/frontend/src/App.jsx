import DashboardPage from "./pages/DashboardPage";

function App() {
  return <DashboardPage />;
}

export default App;
