// hero.ts
import { heroui } from "@heroui/react";
export default heroui();
